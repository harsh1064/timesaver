<?php
include("header.php");
include("sidebar.php");
?>
<?php
include("config.php");
if(isset($_POST['submit']))
{
    $heading=$_POST['heading'];
    $news=$_POST['news'];
   
   
    



    $sql="insert into tbl_news(heading,news)
    value('$heading','$news')";
$result=mysqli_query($con,$sql);
if($result)
{
    echo "record inserted";
}
}
?>

<section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i>Manage news</h3>
        <!-- BASIC FORM VALIDATION -->
        <div class="row mt">
          <div class="col-lg-12">
            <h4><i class=""></i> </h4>
            <div class="form-panel">
              <form role="form"  method="post" class="form-horizontal style-form">
                <div class="form-group has-success">
                  <label class="col-lg-2 control-label">Heading</label>
                  <div class="col-lg-10">
                    <input type="text" name="heading" placeholder="" id="f-name" class="form-control">
                    <p class="help-block"></p>
                  </div>
                </div>


                <div class="form-group has-success">
                  <label class="col-lg-2 control-label">News</label>
                  <div class="col-lg-10">
                    <input type="text" name="news" placeholder="" id="f-name" class="form-control">
                    <p class="help-block"></p>
                  </div>
                </div>
                
                
                <div class="form-group">
                  <div class="col-lg-offset-2 col-lg-10">
                    <button class="btn btn-theme" name="submit" type="submit">Submit</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
    
        <section id="main-content">
      <section class="wrapper">
        <h3 style="margin-left:-209px"><i class="fa fa-angle-right"></i> TABLE</h3>
        <div class="row mb">
        <h4 style="margin-left:-195px"><i class="fa fa-angle-right"></i>Manage news</h4>
          <!-- page start-->
          <div class="content-panel" style="margin-left:-200px">
            <div class="adv-table">
              <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                  <tr>
                    <th>Heading</th>
                    <th>News</th>
                    <th class="hidden-phone">Delete</th>
                    <th class="hidden-phone">Edit</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <tr class="gradeX">

                  <?php
				include("config.php");				  
			if(isset($_REQUEST['start']))
$startno=$_REQUEST['start'];
else
$startno=0;

$pagesize=1;

$pageno=1;

$SqlQuery="SELECT * FROM tbl_news where status=0 limit $startno,$pagesize ";
$SqlQuery1="SELECT * FROM tbl_news where status=0";

$SqlQueryRun=mysqli_query($con,$SqlQuery);
$SqlQueryRun1=mysqli_query($con,$SqlQuery1);

$total_rows=mysqli_num_rows($SqlQueryRun1);
?>					  

                  <?php


while($row=mysqli_fetch_array($SqlQueryRun))
{
    ?>
    
    <tr>
        <td><?php echo $row['heading'];?></td>
        <td><?php echo $row['news'];?></td>
        


       
        
        
        
        <td><a href="news.php?news_id=<?php echo $row['news_id'];?>">
    <img src="img/delete.png"></td>
    <td><a href="editnews.php?news_id=<?php echo $row['news_id'];?>">
    <img src="img/edit.png"></td>
</tr>
<?php

}
?>

                  </tr>
                  
                </tbody>
              </table>



              <center>

<!-- Header and Slogan -->

<!-- pagination elements -->
<div class="pagination_section">

<a href='news.php?start=0'>First</a>
<?php
for($j=0;$j<$total_rows;$j=$j+$pagesize)
{
if($startno==$j)
{
?>

<?php echo $pageno; ?>
<?php
}
else
{
?>
<a href='news.php?start=<?php echo $j; ?>'><?php echo $pageno; ?></a>
<?php
}
$pageno++;
}
?>

  
  
<a href='news.php?start=<?php echo $j-$pagesize; ?>'>Last</a>
</div>

</center>


</div>
</div>































<style>

/* header styling */
h1 {
  color: green;
}

/* pagination position styling *
.pagination_section {
  position: relative;
}

/* pagination styling */
.pagination_section a {
  color: black;
  padding: 10px 18px;
  text-decoration: none;
}

/* pagination hover effect on non-active */
.pagination_section a:hover:not(.active) {
  background-color: #031F3B;
  color: white;
}

/* pagination hover effect on active*/

a:nth-child(5) {
  background-color: green;
  color: white;
}

a:nth-child(1) {
  font-weight: bold;
}

a:nth-child(7) {
  font-weight: bold;
}

.content {
  margin: 50px;
  padding: 15px;
  width: 700px;
  height: 200px;
  border: 2px solid black;
}
</style>
</head>
            </div>
          </div>
          <!-- page end-->
        </div>
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    



    <?php
if(isset($_GET['news_id']))
{
    $news_id=$_GET['news_id'];
    $sql="update tbl_news set status=1 where news_id='$news_id'";
    $result=mysqli_query($con,$sql);
if($result)
{
    echo "record deleted";
}
}
?>


<?php
include("footer.php");
?>
               