<?php
include("header.php");
include("sidebar.php");
?>

<?php
include("config.php");
if(isset($_GET['news_id']))
{
    $news_id=$_GET['news_id'];

    $sql="select * from tbl_news where status=0 and news_id='$news_id'";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result))
    {
 

        $heading=$row['heading'];
        
        $news=$row['news'];
        
    
    }}
    ?>

<section id="main-content">
 <section class="wrapper">
   <h3><i class="fa fa-angle-right"></i>Manage News</h3>
   <!-- BASIC FORM VALIDATION -->
   <div class="row mt">
     <div class="col-lg-12">
       <h4><i class="fa fa-angle-right"></i> </h4>
       <div class="form-panel">
         <form role="form"  method="post" class="form-horizontal style-form">
           <div class="form-group has-success">
             <label class="col-lg-2 control-label">Heading</label>
             <div class="col-lg-10">
               <input type="text" name="heading" value="<?php echo $heading;?>" placeholder="enter your question" id="f-name" class="form-control">
               <p class="help-block"></p>
             </div>
           </div>


           <div class="form-group has-success">
             <label class="col-lg-2 control-label">News</label>
             <div class="col-lg-10">
               <input type="text" name="news" value="<?php echo $news;?>" placeholder="" id="f-name" class="form-control">
               <p class="help-block"></p>
             </div>
           </div>
           
           
           <div class="form-group">
             <div class="col-lg-offset-2 col-lg-10">
               <button class="btn btn-theme" name="submit" type="submit">Submit</button>
             </div>
           </div>
         </form>
       </div>
       <!-- /form-panel -->
     </div>
     <!-- /col-lg-12 -->
   </div>



   <?php
                        include("config.php");
                        if(isset($_POST['submit']))
                        {
                            
                            
                            
                        
                        
                            $heading=$_POST['heading'];
                            $news=$_POST['news'];
                            
                            
                            
                        
                        
                        
                        
                        
                        
                           
                            $sql="update tbl_news set heading='$heading',news='$news'
                             where status=0 and news_id='$news_id'";
                        $result=mysqli_query($con,$sql);
                        if($result)
                        {
                            echo "<script>alert('news updated successfully');</script>";
                            echo "<script>window.location.href='news.php';</script>";
                        }
                            }
                        ?>
                        
                            

   
                            
                            <?php
                        include("footer.php");
                        ?> 