<?php
include("header.php");
include("sidebar.php");
?>

<?php
include("config.php");
if(isset($_GET['faq_id']))
{
    $faq_id=$_GET['faq_id'];

    $sql="select * from tbl_faq where status=0 and faq_id='$faq_id'";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result))
    {
 

        $question=$row['question'];
        
        $answer=$row['answer'];
        
    
    }}
    ?>

<section id="main-content">
 <section class="wrapper">
   <h3><i class="fa fa-angle-right"></i>Manage Faq</h3>
   <!-- BASIC FORM VALIDATION -->
   <div class="row mt">
     <div class="col-lg-12">
       <h4><i class="fa fa-angle-right"></i> </h4>
       <div class="form-panel">
         <form role="form"  method="post" class="form-horizontal style-form">
           <div class="form-group has-success">
             <label class="col-lg-2 control-label">Question</label>
             <div class="col-lg-10">
               <input type="text" name="question" value="<?php echo $question;?>" placeholder="enter your question" id="f-name" class="form-control">
               <p class="help-block"></p>
             </div>
           </div>


           <div class="form-group has-success">
             <label class="col-lg-2 control-label">Answer</label>
             <div class="col-lg-10">
               <input type="text" name="answer" value="<?php echo $answer;?>" placeholder="" id="f-name" class="form-control">
               <p class="help-block"></p>
             </div>
           </div>
           
           
           <div class="form-group">
             <div class="col-lg-offset-2 col-lg-10">
               <button class="btn btn-theme" name="submit" type="submit">Submit</button>
             </div>
           </div>
         </form>
       </div>
       <!-- /form-panel -->
     </div>
     <!-- /col-lg-12 -->
   </div>



   <?php
                        include("config.php");
                        if(isset($_POST['submit']))
                        {
                            
                            
                            
                        
                        
                            $question=$_POST['question'];
                            $answer=$_POST['answer'];
                            
                            
                            
                        
                        
                        
                        
                        
                        
                           
                            $sql="update tbl_faq set question='$question',answer='$answer'
                             where status=0 and faq_id='$faq_id'";
                        $result=mysqli_query($con,$sql);
                        if($result)
                        {
                            echo "<script>alert('faq updated successfully');</script>";
                            echo "<script>window.location.href='faq.php';</script>";
                        }
                            }
                        ?>
                        
                            

   
                            
                            <?php
                        include("footer.php");
                        ?> 