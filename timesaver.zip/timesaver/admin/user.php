<?php
include("header.php");
include("sidebar.php");
?>
    
        <section id="main-content">
      <section class="wrapper">
        <h3 style="margin-left:-209px"><i class="fa fa-angle-right"></i> TABLE</h3>
        <div class="row mb">
        <h4 style="margin-left:-195px"><i class="fa fa-angle-right"></i>Manage User</h4>
          <!-- page start-->
          <div class="content-panel" style="margin-left:-200px">
            <div class="adv-table">
              <table cellpadding="0" style="    width: 85%;
    margin-left: 14%;" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                  <tr>
                  <th class="hidden-phone">email</th>
                    
                    <th class="hidden-phone">username</th>
                    <th class="hidden-phone">city</th>
                    <th class="hidden-phone">address</th>
                    <th class="hidden-phone">gender</th>
                    <th class="hidden-phone">image</th>
                    <th class="hidden-phone">mobile_no</th>
                    
                    <th class="hidden-phone">Delete</th>
                    
                    
                  </tr>
                </thead>
                <tbody>
                  <tr class="gradeX">
                  <?php
                  include("config.php");
$sql="select * from tbl_register where status=0";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <tr>
        <td><?php echo $row['email'];?></td>
      
        <td><?php echo $row['username'];?></td>
        <td><?php echo $row['city'];?></td>
        <td><?php echo $row['address'];?></td>
        <td><?php echo $row['gender'];?></td>
        <td><img src="../registerimage/<?php echo $row['image'];?>" style="width:50px;height:50px;"></td>
        <td><?php echo $row['mobile_no'];?></td>
       
        
        <td><a href="user.php?register_id=<?php echo $row['register_id'];?>">
    <img src="img/delete.png"></td>
    
</tr>
<?php

}
?>

                  </tr>
                  
                </tbody>
              </table>
            </div>
          </div>
          <!-- page end-->
        </div>
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    



    <?php
if(isset($_GET['register_id']))
{
    $register_id=$_GET['register_id'];
    $sql="update tbl_register set status=1 where register_id='$register_id'";
    $result=mysqli_query($con,$sql);
if($result)
{
    echo "record deleted";
}
}
?>


<?php
include("footer.php");
?>