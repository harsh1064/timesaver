<?php
include("header.php");
include("sidebar.php");
?>
   


<section id="main-content">
      <section class="wrapper">
        <h3 style="margin-left:-209px;color:red"><i class="fa fa-angle-right"></i><B> TABLE</B></h3>
        
        <h4 style="margin-left:-206px;color:black"><i class="fa fa-angle-right"></i><B>Manage Get in touch</B></h4>
        <div class="row mb">
        <!-- page start-->
          <div class="content-panel" style="margin-left:-200px">
            <div class="adv-table">
              <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info" style=" width: 85%;
    margin-left: 217px"
}
                <thead>
                  <tr>
                    <th>cat Name</th>
                    <th>Name</th>
                    <th class="hidden-phone">email</th>
                    <th class="hidden-phone">mobileno</th>
                    <th class="hidden-phone">pincode</th>
                   
                    
                    <th class="hidden-phone">Delete</th>
                   
                
                </tr>
                </thead>
                <tbody>
                  <tr class="gradeX">
                  <?php
 include("config.php");
 $sql="select pl.cat_name,lgn.* from tbl_getintouch lgn INNER JOIN tbl_category pl ON
 pl.cat_id=lgn.cat_id where lgn.status=0";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <tr>
        <td><?php echo $row['cat_name'];?></td>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['email'];?></td>
        <td><?php echo $row['mobileno'];?></td>
        <td><?php echo $row['pincode'];?></td>
        

        
        <td><a href="getintouch.php?get_id=<?php echo $row['get_id'];?>">
    <img src="img/delete.png"></td>
    
</tr>
<?php

}
?>              </tr>
                  
                </tbody>
              </table>
            </div>
          </div>
          <!-- page end-->
        </div>
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>

    
<?php
if(isset($_GET['get_id']))
{
    $get_id=$_GET['get_id'];
    $sql="update tbl_getintouch set status=1 where get_id='$get_id'";
    $result=mysqli_query($con,$sql);
if($result)
{
    echo "record deleted";
}
}
?>
<?php
include("footer.php");
?>