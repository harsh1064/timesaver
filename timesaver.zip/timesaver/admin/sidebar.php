<aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="index.php"><img src="img/user.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered"></h5>
          <li class="mt">
            <a class="active" href="index.php">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>

          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-home"></i>
              <span>Our services</span>
              </a>
            <ul class="sub">
            <li class="mt">
            <a  href="category1.php">
              <i class="fa fa-list-alt" aria-hidden="true"></i>
              <span>Manage Category</span>
              </a>
          </li>
          <li class="mt">
            <a  href="service.php">
            <i class="fa fa-wrench" aria-hidden="true"></i>
              <span>Service</span>
              </a>
          </li>
          <li class="mt">
            <a  href="partener.php">
              <i class="fa fa-handshake-o"></i>
              <span> Service partener</span>
              </a>
          </li>
          <!-- <li class="mt">
            <a  href="booking.php">
              <i class="fa fa-book"></i>
              <span>Manage booking</span>
              </a>
          </li>-->

          <!-- <li class="mt">
            <a  href="managecardpayment.php">
              <i class="fa fa-credit-card"></i>
              <span>Manage card payment</span>
              </a>
          </li>-->
           <!--<li class="mt">
            <a  href="managerazorpay.php">
              <i class="fa fa-cc-visa"></i>
              <span>Manage Razorpay </span>
              </a>
          </li>-->

            </ul>
          </li>

          

 <li class="mt">
            <a  href="user.php">
              <i class="fa fa-user"></i>
              <span>Manage User</span>
              </a>
          </li>

          <li class="mt">
            <a  href="usercontact.php">
              <i class="fa fa-phone"></i>
              <span>Manage Contact</span>
              </a>
          </li>

          <li class="mt">
            <a  href="getintouch.php">
              <i class="fa fa-address-book"></i>
              <span>Manage Get in touch</span>
              </a>
          </li>

  <li class="mt">
            <a  href="booking.php">
              <i class="fa fa-book"></i>
              <span>Manage booking</span>
              </a>
          </li>

           <li class="mt">
            <a  href="managecardpayment.php">
              <i class="fa fa-credit-card"></i>
              <span>Manage card payment</span>
              </a>
          </li>
           <li class="mt">
            <a  href="managerazorpay.php">
              <i class="fa fa-cc-visa"></i>
              <span>Manage Razorpay </span>
              </a>
          </li>

          <li class="mt">
            <a  href="faq5.php">
              <i class="fa fa-question-circle"></i>
              <span>Manage Faq</span>
              </a>
          </li>

          
          <li class="mt">
            <a  href="news.php">
              <i class="fa fa-newspaper-o"></i>
              <span>Manage News</span>
              </a>
          </li>

          <li class="mt">
            <a  href="city.php">
            <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>Manage city </span>
              </a>
          </li>


           <li class="mt">
            <a  href="feedback.php">
              <i class="fa fa-comments-o"></i>
              <span>Manage feedback</span>
              </a>
          </li>

           <li class="mt">
            <a  href="complain.php">
              <i class="fa fa-microchip"></i>
              <span>Manage Complain</span>
              </a>
          </li>
          
          <li class="mt">
            <a  href="rating.php">
              <i class="fa fa-star"></i>
              <span>Manage Rating </span>
              </a>
          </li>

         

        <!-- sidebar menu end-->
      </div>
    </aside>