<?php
include("header.php");
?>

<div class="ww" style="margin: 0 !important;
    padding: 0 !important;
    position: fixed !important;
    z-index: 16000160 !important;
    bottom: 0 !important;
    text-align: center !important;
    height: 90px;
    width: 54px;
    visibility: visible;
    transition: none !important;right:21px;">
   
<a href="https://wa.me/7285075147?text=I%27d%20like%20to%20chat%20with%20you" target="_blank"><img src="images/w4.png" style="width:50px;position:fixed"></image></a>

</div>
<!--End Main Header -->

    <!--Main Slider-->
    <section class="main-slider">
    	
        <div class="rev_slider_wrapper fullwidthbanner-container"  id="rev_slider_one_wrapper" data-source="gallery">
            <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">
                <ul>
                
                	<li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1687" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-3.jpg" data-title="Slide Title" data-transition="parallaxvertical">
                    <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/f1.jpg"> 
                    
                    <div class="tp-caption" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','700','650','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['-130','-120','-110','-90']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<div class="title"></div>
                    </div>
                    
                    <div class="tp-caption" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','700','650','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['-60','-50','-40','-30']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<h2 class="alternate"><span class="theme_color"></span> </h2>
                    </div>
                    
                    <div class="tp-caption tp-resizeme" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-whitespace="normal"
                    data-width="['720','700','650','550']"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['20','25','20','25']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<div class="text"></div>
                    </div>
                    
                    <div class="tp-caption tp-resizeme" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','700','650','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['110','115','90','105']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	
                    </div>
                    
                    </li>
                    
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1688" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-6.jpg" data-title="Slide Title" data-transition="parallaxvertical">
                    <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/t3.jpg">
                    
                    <div class="tp-caption" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','600','550','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['-130','-110','-90','-75']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<div class="title"></div>
                    </div>
                    
                    <div class="tp-caption" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','600','550','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['-60','-110','-90','-75']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<h2 class="alternate"><span class="theme_color"></span> </h2>
                    </div>
                    
                    <div class="tp-caption tp-resizeme" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-whitespace="normal"
                    data-width="['720','700','650','550']"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['20','15','10','5']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<div class="text"></div>
                    </div>
                    
                    <div class="tp-caption tp-resizeme" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','600','550','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['110','105','90','95']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	
                    </div>
                    
                    </li>
                    
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/home.jpg" data-title="Slide Title" data-transition="parallaxvertical">
                    <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/home-3.jpg">
                    
                    <div class="tp-caption" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','600','550','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['-130','-110','-90','-75']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<div class="title"></div>
                    </div>
                    
                    <div class="tp-caption" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','600','550','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['-60','-110','-90','-75']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<h2 class="alternate"><span class="theme_color"></span> </h2>
                    </div>
                    
                    <div class="tp-caption tp-resizeme" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-whitespace="normal"
                    data-width="['720','700','650','550']"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['20','15','10','5']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	<div class="text"></div>
                    </div>
                    
                    <div class="tp-caption tp-resizeme" 
                    data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[0,0,0,0]"
                    data-paddingright="[0,0,0,0]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text"
                    data-height="none"
                    data-width="['720','600','550','550']"
                    data-whitespace="normal"
                    data-hoffset="['15','15','15','15']"
                    data-voffset="['110','105','90','95']"
                    data-x="['left','left','left','left']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                    	
                    </div>
                    
                    </li>
                    
                </ul>
            </div>
        </div>
        <div class="contact-number"><span class="icon flaticon-phone-call"></span>Call Us:+917285075147</div>
    </section>
    <!--End Main Slider-->
    
    <!--Success Section-->
    <section class="success-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            	
                <!--Image Column-->
                <div class="image-column col-md-5 col-sm-12 col-xs-12">
                	<div class="inner-column">
                    	<div class="image">
                        	<img src="images/a3.jpg" alt="" />
                        </div>
                        <div class="small-img">
                        	<img src="images/a1.jpg" alt="" />
                        </div>
                    </div>
                </div>
                <!--Content Column-->
                <div class="content-column col-md-7 col-sm-12 col-xs-12">
                	<div class="inner-column">
                    	<div class="since-year clearfix">
                        	<span class="title"></span>
                            
                            <div class="work">WELCOME TO<strong>TimeSaver</strong><span>Website</span></div>
                        </div>
                        <div class="text" style="text-align:justify"> our platform helps customers book reliable & high quality services - home cleaning, Tutor, appliance repair, maid service,carpenter, pest control and more – delivered by trained professionals conveniently at home. TimeSaver's vision is to empower millions of professionals worldwide to deliver services at home like never experienced before.TimeSaver is the leading platform for connecting individuals looking for household services with top-quality, pre-screened independent service professionals With a seamless 60-second booking process, secure payment, and backed by the  Happiness Guarantee, TimeSaver is the easiest, most convenient way to book home services.</div>
                        
                        <div class="fact-counter">
                            <div class="row clearfix">
                            
                                <!--Column-->
                                <div class="column counter-column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3500" data-stop="100">0</span>
                                            <h4 class="counter-title">Professionals</h4>
                                        </div>
                                    </div>
                                </div>
                        
                                <!--Column-->
                                <div class="column counter-column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="2500" data-stop="500">0</span>
                                            <h4 class="counter-title">Customers</h4>
                                        </div>
                                    </div>
                                </div>
                        
                                <!--Column-->
                                <div class="column counter-column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="2200" data-stop="5">0</span>
                                            <h4 class="counter-title">District</h4>
                                        </div>
                                    </div>
                                </div>
                        
                                <!--Column-->
                                <div class="column counter-column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="2000" data-stop="20">0</span>
                                            <h4 class="counter-title">cities</h4>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                                
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!--End Success Section-->
    
    <!--Services Section Two-->
    <section class="services-section-two" style="background-image:url(images/background/4.jpg)">
    	<div class="auto-container">
        	<div class="sec-title centered">
            	<div class="title">Services We Offer & Solutions</div>
                <h2><span class="theme_color">Our</span> Main Services</h2>
            </div>
            <div class="row clearfix">
                
                <!--Services Block Two-->
                <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<div class="icon-box">
                            	<span class="icon flaticon-drawing"></span>
                            </div>
                            <h3><a href="#">Tutor</a></h3>
                        </div>
                        <div class="text">Tutor responsibilities include:
Reviewing classroom or curricula topics and assignments.</div>
                        <a href="#" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                    </div>
                </div>
                
                <!--Services Block Two-->
                <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<div class="icon-box">
                            	<span class="icon flaticon-brickwall"></span>
                            </div>
                            <h3><a href="#">Babysitter</a></h3>
                        </div>
                        <div class="text">babysitter do Ensuring child safety,

Playing games and having fun,
Changing diapers.

</div>
                        <a href="#" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                    </div>
                </div>
                
                <!--Services Block Two-->
                <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<div class="icon-box">
                            	<span class="icon flaticon-worker-of-construction-working-with-a-shovel-beside-material-pile"></span>
                            </div>
                            <h3><a href="#">Gardener</a></h3>
                        </div>
                        <div class="text">Gardener responsibilities include monitoring the health of all plants and greenscapes.</div>
                        <a href="#" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                    </div>
                </div>
                
                <!--Services Block Two-->
                <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<div class="icon-box">
                            	<span class="icon flaticon-home-2"></span>
                            </div>
                            <h3><a href="#">Real estate broker</a></h3>
                        </div>
                        <div class="text">Real estate broker is an individual who acts as an intermediary between the seller and the buyer of a property.</div>
                        <a href="#" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                    </div>
                </div>
                
                <!--Services Block Two-->
                <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<div class="icon-box">
                            	<span class="icon flaticon-window"></span>
                            </div>
                            <h3><a href="#">Water tanker supply</a></h3>
                        </div>
                        <div class="text">we supply large amount of water through tanker.we provide 4000 litre water through tanker.</div>
                        <a href="#" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                    </div>
                </div>
                
                <!--Services Block Two-->
                <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                	<div class="inner-box">
                    	<div class="upper-box">
                        	<div class="icon-box">
                            	<span class="icon flaticon-concrete-mixer"></span>
                            </div>
                            <h3><a href="#">Maid service</a></h3>
                        </div>
                        <div class="text">Maid Responsibilities include
Sweeping, mopping, dusting, and vacuuming to remove dirt, debris, and dust from floors and other surfaces. </div>
                        <a href="#" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!--End Services Section Two-->
    
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            	
                <!--Accordian Column-->
                <div class="accordian-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-column">
                        <div class="sec-title">
                            <div class="title">Fequality Ask Question</div>
                            <h2><span class="theme_color">some</span> Faq's</h2>
                        </div>
                        
                        <!--Accordian Box-->
                        <ul class="accordion-box">
                       
                        <?php
$sql="select * from tbl_faq where status=0";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    



       
                            
                            <!--Block-->
                            <li class="accordion block">
                                <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-plus"></span> <span class="icon icon-minus fa fa-minus"  ></span></div>
                                <?php echo $row['question'];?></div>
                                

                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text"><?php echo $row['answer'];?></div>                 </div>
                                </div>
                            </li>

                            <?php

}
?>

    
                            <!--Block-->
                            
                            
                            <!--Block-->
                            
                            
                        </ul>
                        
                    </div>
                </div>







                
                <!--Testimonial Column-->
                <div class="testimonial-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-column">
                    	
                        <div class="sec-title">
                            <div class="title">Testimonial</div>
                            <h2><span class="theme_color">clients</span> say</h2>
                        </div>
                        
                        <div class="single-item-carousel owl-carousel owl-theme">
                        	
                            <!--Testimonial Block-->
                            <div class="testimonial-block-two">
                            	<div class="inner-box">
                                	<div class="upper-box">
                                        <div class="quote-icon">
                                            <span class="icon flaticon-quote-left"></span>
                                        </div>
                                    	<div class="text">“i would like to thank for your tutor service.The tutor was very knowledgeable in the subjects. I really appreciate how hard you all work to meet the students needs especially with regards to matching the tutor with the student. “</div>
                                    </div>
                                    <div class="lower-box">
                                    	<div class="author-box">
                                        	<div class="author-inner">
                                            	<div class="image">
                                                	<img src="images/bhavya.jpg" alt="" />
                                                </div>
                                                <h3>Bhavya chaudhary</h3>
                                                <div class="designation">Consultant</div>
                                            </div>
                                        </div>
                                        <div class="rating">
                                        	<span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Testimonial Block-->
                            <div class="testimonial-block-two">
                            	<div class="inner-box">
                                	<div class="upper-box">
                                        <div class="quote-icon">
                                            <span class="icon flaticon-quote-left"></span>
                                        </div>
                                    	<div class="text">“you are doing termite and general disinfection pest control at our society.we found it is satisfactory and prompt,we appriciate the way you trained your staff and the way they following their duty.keep up the good work. “</div>
                                    </div>
                                    <div class="lower-box">
                                    	<div class="author-box">
                                        	<div class="author-inner">
                                            	<div class="image">
                                                	<img src="images/kishan.jpg" alt="" />
                                                </div>
                                                <h3>Kishan Modi</h3>
                                                <div class="designation">Consultant</div>
                                            </div>
                                        </div>
                                        <div class="rating">
                                        	<span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Testimonial Block-->
                            <div class="testimonial-block-two">
                            	<div class="inner-box">
                                	<div class="upper-box">
                                        <div class="quote-icon">
                                            <span class="icon flaticon-quote-left"></span>
                                        </div>
                                    	<div class="text">“
I want you to know that your cleaners did an AMAZING job cleaning my home! I was highly impressed with their efficiency and willingness to go above and beyond making sure that my home is dust free! I look forward to working with either of them in the coming weeks. “</div>
                                    </div>
                                    <div class="lower-box">
                                    	<div class="author-box">
                                        	<div class="author-inner">
                                            	<div class="image">
                                                	<img src="images/DHRUVI.jpg" alt="" />
                                                </div>
                                                <h3>Dhruvi patel</h3>
                                                <div class="designation">Consultant</div>
                                            </div>
                                        </div>
                                        <div class="rating">
                                        	<span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star-o"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!--End Default Section-->
   
    <!--End Project Section Two-->
    
    <!--Price Section-->
    
    <!--End Price Section-->
    
    <!--Team Section-->
    <section class="project-section">
    	<div class="auto-container">
        	<div class="sec-title centered">
            	<div class="title"></div>
                <h2><span class="theme_color">Our </span>Category</h2>
            </div>
            
            <!--MixitUp Galery-->
            <div class="mixitup-gallery">
                
               
                
                <div class="filter-list row clearfix">
                <?php
include("config.php");
$sql = "select * from tbl_category where status=0";
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($result))
{
    $path="catimage/".$row['image'];
?>
                    <!--Gallery Item-->
                    <div class="gallery-item mix all agriculture col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    
                        <div class="inner-box">




                            <figure class="image-box">
                               

                                <?php echo "<img alt='' class='img-responsive' src='./admin/catimage/$row[2]'style='height:270px;width:370px;'>" ?>

                                <!--Overlay Box-->
                                <div class="overlay-box">
                                <h3>   <a  href="allservice.php?cat_id=
						<?php echo $row['cat_id'];?>" >
         <?php echo $row['cat_name'];?></a></h3>

         
                                    <div class="overlay-inner">

                                    
                                       
                                        </div>
                                    </div>
                                </div>
                            </figure>
                             <div class="content">

                                        
                                        
                                     <h3>   <a  href="allservice.php?cat_id=
						<?php echo $row['cat_id'];?>" >
         <?php echo $row['cat_name'];?></a></h3>
                                            <div class="category"></div>
                        </div>
                    </div>
                    
                    <!--Gallery Item-->
                   
<?php
}
?>



                    
                </div>                    
                
            </div>
            
            <!--Styled Pagination-->
            <ul class="styled-pagination text-center">
            	<li class="prev"><a href="#"><span class="fa fa-angle-double-left"></span> Prev</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#" class="active">2</a></li>
                <li><a href="#">3</a></li>
                <li class="next"><a href="#">Next <span class="fa fa-angle-double-right"></span></a></li>
            </ul>                
            <!--End Styled Pagination-->
            
        </div>
    </section>
    
    <!--News Section Two-->
    <section class="news-section-two">
    	<div class="auto-container">
        	<div class="sec-title">
            	<div class="title">Recent Blogs</div>
                <h2><span class="theme_color">Our</span> Latest News</h2>
            </div>
            <div class="two-item-carousel owl-carousel owl-theme">


            
            	<!--News Block-->
                <?php
$sql="select * from tbl_news where status=0";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
    ?>
                <div class="news-block-two">

                
                    
                    <div class="inner-box"style="border:2 px solid black">
                        <div class="clearfix">
                            <div class="image-column col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <div class="image" >
                                    <img src="images/news.jpg" alt="" />
                                    <div class=""></div>
                                    <a href="blog-detail.html" class="overlay-box">
                                        <span class="icon fa fa-link"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="content-column col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <div class="content-box">
                                    <h3><a href="blog-detail.html"><?php echo $row['heading'];?></a></h3>
                                    <div class="text"><?php echo $row['news'];?></div>
                                    <ul class="options clearfix">
                                        <li><a href="blog-detail.html"><span class=""></span>&ensp; </a></li>
                                        <li><a href="#">Read More <span class="icon fa fa-angle-double-right"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            
                
    </section>
    <!--End News Section Two-->
    
    <!--Call To Action Two-->
   
    <!--End Call To Action Two-->
    
  <?php
  include("footer.php");
  ?>


   
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="icon fa fa-angle-double-up"></span></div>

<!-- Color Palate / Color Switcher -->
<div class="color-palate">
    <div class="color-trigger">
        <i class="fa fa-gear"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Color</h6>
    </div>
    <div class="various-color clearfix">
        <div class="colors-list">
            <span class="palate default-color active" data-theme-file="css/color-themes/default-theme.css"></span>
            <span class="palate teal-color" data-theme-file="css/color-themes/teal-theme.css"></span>
            <span class="palate green-color" data-theme-file="css/color-themes/green-theme.css"></span>
            <span class="palate aqua-color" data-theme-file="css/color-themes/aqua-theme.css"></span>
            <span class="palate pink-color" data-theme-file="css/color-themes/pink-theme.css"></span>
            <span class="palate orange-color" data-theme-file="css/color-themes/orange-theme.css"></span>
            <span class="palate lime-color" data-theme-file="css/color-themes/lime-theme.css"></span>
            <span class="palate red-color" data-theme-file="css/color-themes/red-theme.css"></span>
        </div>
    </div>

    <div class="palate-foo">
        <span>You can easily change and switch the colors.</span>
    </div>

</div>
<!-- /.End Of Color Palate -->

<script src="js/jquery.js"></script> 
<!--Revolution Slider-->
<script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/main-slider-script.js"></script>

<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/validate.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/appear.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>

<!--Color Switcher-->
<script src="js/color-settings.js"></script>
</body>


<!-- Mirrored from danslacuisinededede.com/constructo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 18 Jul 2022 10:19:43 GMT -->
</html>